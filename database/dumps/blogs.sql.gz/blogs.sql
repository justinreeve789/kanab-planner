-- MySQL dump 10.13  Distrib 8.0.41, for Linux (x86_64)
--
-- Host: mysql    Database: kanabapi
-- ------------------------------------------------------
-- Server version	9.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `blogs`
--

LOCK TABLES `blogs` WRITE;
/*!40000 ALTER TABLE `blogs` DISABLE KEYS */;
INSERT INTO `blogs` (`id`, `name`, `url`, `created_at`, `updated_at`) VALUES (1,'Girl on a Hike','https://girlonahike.com','2025-04-01 19:18:18','2025-04-01 19:18:18'),(2,'Matt and Karen','https://mattandkaren.com','2025-04-01 19:18:56','2025-04-01 19:18:56'),(3,'Uprooted Traveler','https://uprootedtraveler.com','2025-04-01 19:18:57','2025-04-01 19:18:57'),(4,'Alexys Abroad','https://alexysabroad.com','2025-04-01 19:18:57','2025-04-01 19:18:57'),(5,'Adventures with TuckNae','https://adventureswithtucknae.com','2025-04-01 19:43:01','2025-04-01 19:43:01'),(6,'USA Adventurer','https://usadventurer.com','2025-04-01 20:18:00','2025-04-01 20:18:00'),(7,'Red Around the World','https://redaroundtheworld.com','2025-04-08 18:03:32','2025-04-08 18:03:32'),(8,'Kanab Tour Company','https://kanabtourcompany.com','2025-04-08 18:06:34','2025-04-08 18:06:34'),(9,'Wildland Trekking','https://wildlandtrekking.com','2025-04-11 00:20:33','2025-04-11 00:20:33'),(10,'HikingGuy','https://hikingguy.com','2025-04-11 14:44:37','2025-04-11 14:44:37'),(11,'Plate & Compass','https://plateandcompass.com','2025-04-15 05:39:18','2025-04-15 05:39:18'),(12,'Nomads with a Purpose','https://www.nomadswithapurpose.com','2025-04-15 05:42:00','2025-04-15 05:42:00'),(13,'Cate\'s Compass','https://catescompass.com','2025-04-16 13:51:25','2025-04-16 13:51:25'),(14,'Visit Southern Utah','https://visitsouthernutah.com','2025-04-16 13:55:19','2025-04-16 13:55:19');
/*!40000 ALTER TABLE `blogs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-16  8:01:47
